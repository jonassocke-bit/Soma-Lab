# Sammy v0.8.27.1 · Body Fit Priority Fix

Der erste Minimal-Body-Fit zeigte eine falsche Priorität: Fülle konnte an 100 % stehen, obwohl das aus Meshvolumen geschätzte Gewicht noch deutlich unter der Eingabe lag. Gleichzeitig wurde Muskulatur nur als statistischer Prior behandelt. v0.8.27.1 macht das Zielgewicht zu einem frühen Hauptziel und lässt Weight/Muscle anhand ihrer tatsächlichen Meshwirkung zusammenarbeiten. Danach werden Taille und insbesondere Hüfte wiederhergestellt.

Der Produktionspfad bleibt absichtlich klein: fünf Nutzereingaben, ANSUR nur Statistik, wenige direkte Anny-Regler, keine 24-Maß-Rekonstruktion.
