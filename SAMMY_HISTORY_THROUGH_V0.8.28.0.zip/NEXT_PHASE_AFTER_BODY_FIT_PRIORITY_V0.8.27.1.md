# Nächster Test nach v0.8.27.1

Den gleichen weiblichen Fall wie im ersten v0.8.27.0-Test erneut eingeben.

Prüfen:
- Avatar-Gewicht soll nach dem frühen Masseschritt grob innerhalb ±1.5–3 kg liegen, sofern Weight/Muscle im normalen Anny-Raum genug Kapazität haben.
- Wenn `Fülle` am Anschlag ist, muss Body Fit automatisch die gemessene hilfreiche Muscle-Richtung verwenden statt mit großem Restfehler aufzuhören.
- Hüfte/Gesäß soll nach der Masseregelung aktiv auf den Eingabewert zurücklaufen.
- Manueller `Hüfte`-Regler muss die Breiten-/Umfangsregion getrennt vom `Gesäß`-Regler beeinflussen.
- Frauen-Cup bleibt lokal und wird nach einer kleinen Masserückkopplung nochmals angefahren.

Wenn Gewicht und Hüfte so stabil funktionieren, erst danach Brust/Taille oder weitere Makroregler verfeinern.
