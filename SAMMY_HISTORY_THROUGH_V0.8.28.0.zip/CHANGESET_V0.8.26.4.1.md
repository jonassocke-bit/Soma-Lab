# CHANGESET v0.8.26.4.1

Geändert: `app.js`, `index.html`; hinzugefügt: `BOOT_HOTFIX_V0.8.26.4.1.md`, `RELEASE_NOTES_V0.8.26.4.1.md`, `CHANGESET_V0.8.26.4.1.md`.
