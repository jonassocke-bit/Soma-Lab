# CHANGESET v0.8.27.1

- Body Fit Schema auf `sammy-body-fit-minimal-v1.1`.
- Gewicht/Masse wird nun mit `core:weight` + `core:muscle` anhand echter Meshvolumen-Derivate optimiert.
- Muscle-Prior ist nur noch Startwert, kein bei jedem Pass wiederhergestellter Zwang.
- Masse läuft direkt nach der Größenanpassung und erhält höhere Priorität als weiche Formziele.
- Hüfte wird nach Masseschritten gezielt wiederhergestellt.
- Auto-Limit `measure-hips-circ-incr` von ±0.32 auf ±0.78 erweitert.
- `buttocks-volume-incr` nur als regionaler Hüft-Fallback.
- Neuer intuitiver manueller Regler `Hüfte`, getrennt von `Gesäß`.
- Gewicht-Deadband auf ±1.5 kg verschärft; Hüfte auf 2.5 cm.
- UI/Version/Cache auf 0.8.27.1.
