# BODY FIT MINIMAL 1.1 · v0.8.27.1

## Zweck
Korrektur der Prioritäten des neuen Produktionspfads nach dem ersten iPhone-Test.

## Befund aus v0.8.27.0
Der Masseschritt optimierte nur `core:weight`. `core:muscle` wurde lediglich als statistischer Startwert gesetzt und bei jedem Masseschritt erneut auf diesen Prior zurückgesetzt. Wenn `core:weight` am oberen Rand angekommen war, konnte ein großer Masseresidual bestehen bleiben, obwohl eine Änderung der Muskulatur das reale Meshvolumen stark beeinflusst.

Zudem war die automatische Hüftkorrektur auf `measure-hips-circ-incr` mit ±0.32 begrenzt und es gab keinen getrennten intuitiven Hüftregler. Dadurch konnte eine korrekte Masse die Hüfte sichtbar verschlechtern, ohne dass der Produktionspfad sie anschließend ausreichend wiederherstellte.

## Neue Priorität
1. Körperhöhe
2. Masse: real gemessene Meshvolumen-Wirkung von `core:weight` UND `core:muscle`
3. Struktur-/Frame-Prior
4. Taille + Hüfte/Gesäß
5. Masse-Rückkopplung
6. Taille/Hüfte Recovery
7. Frauenbrust separat, danach kleine Masse-Rückkopplung und Cup-Reassert

## Mass Fit
- `core:muscle` ist kein hart geschützter statistischer Zielwert mehr.
- Statistik setzt nur den Startpunkt.
- Pro Iteration werden Weight und Muscle in beide Richtungen am echten Mesh sondiert.
- Der tatsächlich bessere Masseschritt wird übernommen, unabhängig vom Vorzeichen des Morphnamens.
- Ziel-Deadband: ca. ±1.5 kg.
- Keine Cross-Region-DOFs.

## Hüfte
- `measure-hips-circ-incr` darf automatisch bis ±0.78 genutzt werden.
- Zieldeadband für Gesäß-/Hüftumfang: 2.5 cm.
- Falls der direkte Hüftmorph nicht reicht, darf ausschließlich regional `buttocks-volume-incr` als Fallback folgen.
- Nach der zweiten Massekorrektur wird Hüfte/Taille erneut angefahren.
- Neuer manueller Regler `Hüfte`, getrennt von `Gesäß`.

## Unverändert
- 5-Maße-Maske.
- ANSUR nur statistischer Prior.
- Kein 24-Maß-Solver.
- Keine automatische Extrapolation über normale Anny-Grenzen.
- Frauenbrust bleibt separater Cup-/Volumenblock.
