# SOLVER V2 PROOF INSPECTOR 1.0 · v0.8.25.5

## Ziel

Der Inspector verbindet den mathematischen Proof mit dem tatsächlich sichtbaren Körper. Er trennt dabei bewusst vier Ebenen:

- Proof-Messwerte: autoritative ANSUR24-PROT-v2 Multi-State-Messung;
- Solververlauf: gespeicherte A/B/C-History pro Seed;
- finale Meshform: gewählte `solutionShape` im Viewer;
- visuelle Messdarstellung: gemeinsame Übersicht oder einzelner echter MeasurementState.

## Residualfarbe

Die Farbe eines Maßes ist **keine neue Solvergewichtung**. Sie visualisiert den absoluten Fehler relativ zum im ANSUR-Protokoll hinterlegten Allowable Observer Error:

- grün: `protocolUnits <= 1`
- gelb: `1 < protocolUnits <= 2`
- rot: `protocolUnits > 2`

Reliability bleibt separat. Ein reduced-reliability Maß wird gestrichelt gezeichnet, behält aber seine Roh-Observer-Unit-Farbe.

## Zwei Overlay-Modi

### Übersicht

Alle 24 Geometrien werden gemeinsam auf einer standing-basierten Ansicht gezeigt. Das ist eine räumliche Debugansicht. Sie ersetzt keine der zehn Proof-Messposen.

### Exaktes Maß

Klick auf eine Residualzeile:

1. aktuelle Rekonstruktions-Shape anwenden;
2. den in `SAMMY_ANSUR24_V2_SPEC` definierten MeasurementState setzen;
3. `sammyAns24V2MeasureOne()` aufrufen;
4. die strict PROT-Geometrie des Maßes zeichnen;
5. Ziel, Ist, cm-Delta und Observer Units im Inspector anzeigen.

Damit ist klar sichtbar, ob ein Restfehler aus dem Solver stammt und wo der kanonische Operator auf dem aktuellen Mesh misst.

## Replay

Proof 1.4 speichert bereits pro Seed eine History. Der Inspector stellt sie lesbar dar:

- `deep-ranked` → A
- `semantic-fresh-rescue` → B
- `fresh-wide-rescue` → C

Gezeigt werden nur tatsächlich gespeicherte Zustandsmetriken; der Inspector erfindet keine Zwischenschritte und rekonstruiert keine nicht gespeicherten Meshzustände.

## Sicherheit während eines laufenden Proofs

Solange `sammySolverV2Proof.running === true` ist, sind Rekonstruktions-/Target-/MeasurementState-Schalter deaktiviert. Der Inspector darf den Meshzustand eines laufenden Jacobians nicht verändern. Live-Text und bereits vollständig gespeicherte Seed-Records bleiben sichtbar.

## Import

FULL-JSON-Import ist read-only. Importierte Daten werden nicht in die Solver-IndexedDB geschrieben und verändern keinen Browser-Lauf.
