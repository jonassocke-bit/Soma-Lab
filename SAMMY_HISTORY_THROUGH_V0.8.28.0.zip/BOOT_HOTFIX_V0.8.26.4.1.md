# Sammy v0.8.26.4.1 — Boot/UI Hotfix

## Ursache
`sammyRarRender()` enthielt in der alten Representability-Ergebnisansicht einen versehentlich stehen gebliebenen Verweis auf `rc.iterations`, obwohl `rc` in dieser Funktion nicht existiert. Sobald beim Start ein gespeicherter Representability-Lauf geladen wurde, warf das frühe UI-Rendern `ReferenceError: Can\'t find variable: rc`.

## Korrektur
- den fremden Residual-Convergence-Block aus `sammyRarRender()` entfernt; Residual-Details gehören nur in die Pragmatic-Repair-Ansicht, wo `rc` korrekt definiert ist.
- App-/Cache-Version auf `0.8.26.4.1` angehoben.

## Wissenschaftlicher Umfang
Keine Änderung an Solver-V2-Mathematik, anatomischem Routing, Jacobian, MeasurementStates, ANSUR24, Statistical Prefit, Residual Convergence oder Datenassets. Bereits erzeugte Solver-/PRA-Ergebnisse werden durch diesen Fehler nicht ungültig.
