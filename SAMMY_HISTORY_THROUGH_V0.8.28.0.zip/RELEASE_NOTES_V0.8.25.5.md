# Sammy v0.8.25.5 — SOLVER V2 PROOF 1.4 + INSPECTOR 1.0

## Zweck

v0.8.25.5 verändert **nicht** die wissenschaftliche Solver-V2-Proof-1.4-Logik. Direction A/B/C, ANSUR24-PROT-v2, v0.8.24.26-Messgeometrie, Repair v1.6, Reliability, Target-/Seed-Erzeugung und alle PASS/WARN/FAIL-Grenzen bleiben unverändert.

Der Patch macht den laufenden und abgeschlossenen Proof transparent genug, dass Solververhalten nicht mehr nur aus FULL-JSON und Blind-AUDT rekonstruiert werden muss.

## Neu: Proof Inspector 1.0

Im Bereich `LAB → SOLV → PROOF INSPECTOR` stehen jetzt drei gekoppelte Sichten zur Verfügung:

1. **Fertige Körper / Seed-Galerie**
   - jede fertige `solver-v2-proof-case`-Rekonstruktion ist direkt anwählbar;
   - BEST- und FAR-Seeds werden gekennzeichnet;
   - Filter für alle Seeds, Best+Far, nur PASS/WARN und nur FAIL;
   - vorhandene Blind-AUDT-Bewertungen werden bei Browser-Läufen nach Möglichkeit als `AUDT ✓` bzw. `AUDT !` markiert.

2. **A/B/C-Prozess pro Seed**
   - Initialfit und jede gespeicherte History-Zeile werden als Timeline gezeigt;
   - Direction A, B und C bleiben getrennt sichtbar;
   - accepted/rejected, weighted Protocol Units, cm-RMSE, relative Verbesserung, Alpha, Kandidatenzahl und Wide-Pool-Größe sind direkt lesbar;
   - Stop-Grund und B/C-Passzähler werden am Ende ausgewiesen.

3. **ANSUR24-PROT-v2 Residual-Inspektion**
   - alle 24 Maße erscheinen als Residualtabelle mit Ziel, Ist, cm-Delta und Observer-Error-Units;
   - Statusfarbe: grün ≤1 Unit, gelb >1 bis 2 Units, rot >2 Units;
   - reduced-reliability Maße sind zusätzlich gestrichelt/gekennzeichnet;
   - Maßfamilien werden als kompakte RMS-Balken zusammengefasst.

## Körper-Overlay

Für die aktuell gewählte Rekonstruktion kann ein farbiges ANSUR-Overlay im 3D-Viewport eingeblendet werden.

Wichtig für die wissenschaftliche Trennung:

- Die **Mehrfach-Overlay-Ansicht** zeichnet die 24 Messgeometrien gemeinsam auf einer deterministischen Übersichtspose. Sie dient der räumlichen Orientierung und ist nicht die Quelle der Solverwerte.
- Tippt man eine einzelne Residualzeile an, wechselt Sammy in den **autoritativen ANSUR24-PROT-v2 MeasurementState** dieses Maßes und zeichnet genau den aktuellen Operator dort. Damit lassen sich z. B. Thigh, Tibiale, Arm-Längen oder Shoulder/Biacromial in ihrer echten Proof-Messpose prüfen.
- Die numerischen Solverwerte bleiben unverändert die Werte aus den zehn ANSUR MeasurementStates des Proofs.

## Target ↔ Reconstruction

Für normale Round-trip-Targets kann zwischen der gewählten Rekonstruktion und dem intern gespeicherten synthetischen Zielkörper umgeschaltet werden. Kamera/Viewport bleiben damit als schneller visueller Vergleich nutzbar. Conflict-Controls besitzen bewusst keinen entsprechenden Source-Körper-Schalter.

## Live-Transparenz

Während ein Proof läuft, spiegelt der Inspector den bestehenden Solver-Livekanal. Jacobian-Messung, Direction A/B/C, aktueller Fit, DOF-Count bzw. Wide-Pool werden sichtbar. Der 3D-Inspector bleibt während des aktiven Solvers gesperrt, damit eine manuelle Viewport-Auswahl den laufenden Meshzustand nicht verfälschen kann. Nach jedem fertig gespeicherten Seed aktualisiert sich die Galerie.

## Proof FULL Import

Ein exportiertes `Sammy_SOLVER_V2_PROOF_FULL_*.json` kann direkt in den Inspector geladen werden, ohne IndexedDB zu überschreiben. Dadurch können auch ältere Proof-1.3/1.4-Läufe visuell analysiert werden. `Browser-Lauf` schaltet zurück auf den aktuell gespeicherten Proof.

## Auslieferung

Ab v0.8.25.5 werden zwei Archive bereitgestellt:

- vollständiger lauffähiger Build;
- `CHANGED-ONLY` mit ausschließlich gegenüber v0.8.25.4 geänderten/neuen Dateien in gleicher Pfadstruktur plus Changeset/Build-Test.

## Testhinweis

Proof 1.4 selbst ist wissenschaftlich unverändert. Der nächste Quick kann daher direkt mit v0.8.25.5 laufen; sein Ergebnis ist mit v0.8.25.4 Proof 1.4 vergleichbar. Der Inspector ist eine Beobachtungs-/Debugschicht, keine neue Solvervariante.
