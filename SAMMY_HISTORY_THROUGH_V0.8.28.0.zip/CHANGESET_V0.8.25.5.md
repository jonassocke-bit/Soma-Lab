# Changeset v0.8.25.5 gegenüber v0.8.25.4

## Geändert

- `app.js`
  - App-Version 0.8.25.5
  - Proof Inspector 1.0
  - read-only FULL-JSON-Import
  - fertige Seed-Galerie / Best/Far/AUDT-Markierung
  - A/B/C-Timeline
  - Maßfamilien-Auswertung
  - 24er Residualtabelle
  - farbiges ANSUR-Übersichts-Overlay
  - exakte Einzelmaß-MeasurementState-Ansicht
  - Target/Reconstruction-Toggle
  - Live-Mirroring und Refresh nach fertig gespeichertem Seed
  - aktive Solverläufe sperren alle meshverändernden Inspector-Aktionen
- `index.html`
  - Proof Inspector UI unter SOLV
  - Version/Cache-Buster 0.8.25.5
- `style.css`
  - iPhone-taugliches Inspector Layout und Statusdarstellung
- `README.md`
- `PATCH_NOTES.md`
- `RELEASE_NOTES_V0.8.25.5.md`
- `SOLVER_V2_INSPECTOR_1.0_V0.8.25.5.md`
- `BUILD_TEST_V0.8.25.5.txt`
- `BUILD_MANIFEST_V0.8.25.5.json`

## Wissenschaftlich unverändert

Solver V2 Proof bleibt Schema `sammy-solver-v2-proof-v1.4`. Keine Änderung an Direction A/B/C, ANSUR24-PROT-v2, Messgeometrie, Repair v1.6, Reliability, Target-/Seed-Generator oder Proof-Gates.
