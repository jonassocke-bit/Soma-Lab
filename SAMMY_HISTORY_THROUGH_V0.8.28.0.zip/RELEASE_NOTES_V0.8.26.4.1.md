# RELEASE NOTES — v0.8.26.4.1

Kleiner Boot/UI-Hotfix auf v0.8.26.4. Entfernt einen `rc`-ReferenceError beim frühen Rendern gespeicherter Representability-Ergebnisse. Keine wissenschaftliche oder Solver-Änderung.
